# MASTER_INDEX.md

## Goal
Add an AI-generated carousel path to the existing Content Ops app without changing the current template workflow.

## Product decisions locked
- global reusable AI niche library
- markdown prompt assets, editable and versioned
- fixed workflow graph in software
- text approval checkpoint before image generation
- image approval checkpoint before scheduling
- one final generated image per slide
- caption + CTA + hashtags editable in `/queue`
- stage-specific retries only
- metadata retained for future optimizer loops

## Folder guide

### `sql/`
Database migrations and helper views.

### `docs/`
Human-readable implementation specs:
- route map
- worker contracts
- API payload catalog
- service boundaries
- rollout notes

### `openapi/`
Machine-readable API surface for route generation or contract validation.

### `payloads/`
Concrete request/response JSON examples for UI and worker integration.

### `types/`
TypeScript interfaces, enums, and JSON contract helpers.

### `scaffold/`
Suggested file tree for a Next.js App Router implementation.

## Minimal build order
1. Database
2. AI niche CRUD
3. Prompt asset versioning
4. Job create flow
5. Batch planner
6. Text generation + text review
7. Visual spine + image prompt + image generation
8. Image review
9. Packaging + publish handoff
10. Logging + dashboards

## Compatibility guardrails
- Do not remove or rename existing `/Templates`, `/Projects`, `/Jobs`, `/Queue`.
- Do not break existing `posts` publish-state semantics.
- AI generation progress must live in AI-specific tables/state.
- Existing renderer stays in place for template-based posts.
