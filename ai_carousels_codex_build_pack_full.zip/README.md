# AI-Generated Carousels — Codex Build Pack

This pack converts the AI-generated carousel PRD into implementation assets for a Next.js + Postgres/Supabase style stack.

## What is inside
- `MASTER_INDEX.md` — implementation order and file guide
- `docs/route-map.md` — UI routes, API routes, and ownership
- `docs/worker-contracts.md` — queue contracts, stage inputs/outputs, retry rules
- `docs/api-payload-catalog.md` — request/response payload shapes and examples
- `sql/001_ai_generated_carousels.sql` — additive PostgreSQL schema/migration
- `sql/002_seed_enums_and_views.sql` — optional helpers, views, and indexes
- `openapi/ai_generated_carousels.openapi.yaml` — API surface in OpenAPI form
- `payloads/*.json` — concrete request/response payload examples
- `types/*.ts` — TypeScript domain models and worker contracts
- `scaffold/*` — starter file tree for app routes and services

## Core implementation assumptions
- Existing template workflow remains untouched.
- New AI-generated flow is additive and uses the existing scheduling/publishing pipeline downstream.
- Storage supports file uploads for markdown prompt assets and generated slide images.
- Queue system supports stage-specific retries and idempotency keys.
- SQL targets PostgreSQL 15+ and is Supabase-compatible with minor adaptation.

## Recommended implementation order
1. Apply `sql/001_ai_generated_carousels.sql`
2. Apply `sql/002_seed_enums_and_views.sql`
3. Build niche CRUD + prompt asset versioning routes
4. Build job creation for `source_type = AI_GENERATED`
5. Build batch planner + text generation worker
6. Wire `/queue` text approval actions
7. Build visual spine -> image prompt -> image generation workers
8. Wire `/queue` image approval actions
9. Build packaging worker + publish handoff
10. Add observability dashboards and failure tooling

## Notes for Codex
- Treat `WORKFLOW_REFERENCE_MD` as reference material only. Execution order is fixed in software.
- Freeze all active prompt asset versions into a niche snapshot at job creation.
- Do not mutate live prompt files in-place; every replacement is a new immutable version.
- Preserve current `jobs` and `posts` workflow compatibility.
