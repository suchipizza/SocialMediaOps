# API Payload Catalog

All examples assume JSON over HTTPS. File uploads for markdown assets should use multipart form data or signed-upload flow.

## 1) Create AI niche
`POST /api/ai-generated/niches`

### Request
```json
{
  "name": "Mixed Signals and Modern Relationship Ambiguity",
  "slug": "mixed-signals-modern-relationship-ambiguity",
  "description": "Global reusable niche config for AI-generated carousels.",
  "status": "ACTIVE",
  "defaultTextProvider": "anthropic",
  "defaultTextModel": "claude-sonnet",
  "defaultReasoningProvider": "openai",
  "defaultReasoningModel": "gpt-5.4-thinking",
  "defaultImageProvider": "openai",
  "defaultImageModel": "gpt-image-1",
  "defaultLanguage": "en",
  "defaultSlideCount": 10,
  "defaultMixMode": "AUTO_BALANCED"
}
```

### Response
```json
{
  "id": "nch_123",
  "status": "ACTIVE",
  "createdAt": "2026-03-27T16:10:00Z"
}
```

## 2) Upload prompt asset version
`POST /api/ai-generated/niches/:nicheId/assets/:assetType/versions`

Multipart fields:
- `file`
- `filename`
- optional `notes`

### Response
```json
{
  "promptAssetId": "pas_123",
  "versionId": "pav_456",
  "versionNumber": 4,
  "checksum": "sha256:abc...",
  "activeForFutureJobs": true
}
```

## 3) Bulk taxonomy update
`PUT /api/ai-generated/niches/:nicheId/taxonomy`

```json
{
  "rows": [
    {
      "pillarKey": "economics_of_attention",
      "pillarName": "Economics of Attention",
      "pillarIsActive": true,
      "pillarWeight": 3,
      "subangleKey": "one_text_buys_another_week_of_hope",
      "subangleName": "One text can buy another week of hope",
      "subangleIsActive": true,
      "subangleWeight": 2,
      "visualWorldKey": "night_phone_glow",
      "visualWorldName": "Night phone glow"
    }
  ]
}
```

## 4) Create AI-generated job
`POST /api/jobs`

```json
{
  "projectId": "prj_001",
  "sourceType": "AI_GENERATED",
  "startDate": "2026-03-30",
  "targetPostCount": 21,
  "title": "Week 14 AI carousel batch",
  "aiConfig": {
    "nicheId": "nch_123",
    "mixMode": "AUTO_BALANCED",
    "mixConfig": null,
    "language": "en",
    "slideCount": 10,
    "overrideTextProvider": null,
    "overrideTextModel": null,
    "overrideReasoningProvider": null,
    "overrideReasoningModel": null
  }
}
```

### Response
```json
{
  "jobId": "job_789",
  "sourceType": "AI_GENERATED",
  "status": "RUNNING",
  "aiJobConfigId": "ajc_555",
  "aiNicheSnapshotId": "snp_222"
}
```

## 5) Approve text for one post
`POST /api/queue/posts/:postId/approve-text`

```json
{
  "notes": "Looks good. Continue to image stages."
}
```

## 6) Regenerate text for one post
`POST /api/queue/posts/:postId/regenerate-text`

```json
{
  "reason": "Hook is too weak",
  "strategy": "STAGE_ONLY"
}
```

## 7) Approve images for one post
`POST /api/queue/posts/:postId/approve-images`

```json
{
  "notes": "Approve and package."
}
```

## 8) Regenerate images for one post
`POST /api/queue/posts/:postId/regenerate-images`

```json
{
  "reason": "Slides 1 and 4 are visually flat",
  "strategy": "STAGE_ONLY"
}
```

## 9) Bulk approve text
`POST /api/queue/bulk/approve-text`

```json
{
  "jobId": "job_789",
  "postIds": ["pst_1", "pst_2", "pst_3"]
}
```

## 10) Bulk approve images
`POST /api/queue/bulk/approve-images`

```json
{
  "jobId": "job_789",
  "postIds": ["pst_1", "pst_2", "pst_3"]
}
```

## 11) Update caption / CTA / hashtags
`PATCH /api/queue/posts/:postId/caption`

```json
{
  "captionBody": "This is not confusion. It is intermittent reassurance creating attachment maintenance.",
  "captionCta": "Save this for the next time inconsistency starts to feel like chemistry.",
  "hashtags": ["#Breadcrumbing", "#AttachmentPsychology", "#ModernRelationships"]
}
```

## 12) Update slide copy manually
`PATCH /api/queue/posts/:postId/slides`

```json
{
  "slides": [
    {
      "slideIndex": 1,
      "headline": "That text was not intimacy.",
      "bodyCopy": "It was reassurance calibrated to keep hope alive."
    }
  ],
  "invalidateDownstreamImages": true
}
```

## 13) Internal retry stage
`POST /api/internal/ai/posts/:postRunId/retry-stage`

```json
{
  "stage": "GENERATE_SLIDE_IMAGES",
  "reason": "Provider timeout"
}
```
