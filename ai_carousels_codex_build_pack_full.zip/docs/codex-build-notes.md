# Codex Build Notes

## Recommended technical assumptions
- Frontend: Next.js App Router
- Database: Postgres / Supabase
- Storage: Supabase Storage or S3-compatible
- Queue: pg-boss, Trigger.dev, or a Redis-backed queue
- Validation: Zod
- Worker idempotency: hash-based key per stage

## Where the existing workflow stays in control
- schedule calculation
- publish timing
- Instagram/TikTok publish adapters
- job pause/resume/stop semantics
- queue listing UI patterns

## Where the new workflow adds logic
- AI niche library
- snapshot freeze at job creation
- AI stage machine
- text/image review actions
- artifact persistence
- retry orchestration

## Risk areas to protect early
- prompt asset replacement and snapshot correctness
- partial regeneration invalidation logic
- caption edit should not invalidate images
- slide text edit must invalidate downstream images
- stage retry must not duplicate assets

## Suggested first smoke tests
1. Create niche
2. Upload all required markdown assets
3. Create AI-generated job with 3 posts
4. Confirm snapshot freeze uses current asset head versions
5. Complete text approval for one post
6. Generate images for one post
7. Approve images, package, and hand off to scheduler
8. Edit caption in queue and verify no image invalidation
