# Rollout Plan

## Phase 1 — Data model + niche library
- apply schema
- build `/ai-generated`
- implement prompt asset versioning
- implement taxonomy activation/weights

## Phase 2 — Job creation + batch planning
- extend `POST /api/jobs`
- freeze `ai_niche_snapshot`
- create `ai_post_runs`

## Phase 3 — Text generation + review
- implement text provider adapters
- write text worker
- render text review cards in `/queue`
- support approve-all and regenerate one

## Phase 4 — Visual spine + image prompt + image generation
- implement stage workers
- persist artifacts
- render image review state in `/queue`

## Phase 5 — Packaging + publishing handoff
- finalize generated slide assets
- keep existing scheduler/publisher unchanged
- verify caption assembly

## Phase 6 — Observability + hardening
- metrics dashboard
- dead-letter handling
- admin troubleshooting page
- prompt diff viewer
