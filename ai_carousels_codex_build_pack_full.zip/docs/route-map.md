# Route Map

This route map assumes a Next.js App Router frontend with route handlers under `app/api/*`.

## UI routes

### Existing routes that stay unchanged
- `/templates`
- `/projects`
- `/jobs`
- `/jobs/[jobId]`
- `/queue`

### New routes
- `/ai-generated`
  - list all global AI niches
- `/ai-generated/new`
  - create niche
- `/ai-generated/[nicheId]`
  - niche overview, active bundle, model defaults
- `/ai-generated/[nicheId]/assets`
  - prompt asset registry and version history
- `/ai-generated/[nicheId]/taxonomy`
  - pillar/sub-angle activation, weight controls
- `/ai-generated/[nicheId]/versions`
  - niche snapshot and bundle history
- `/jobs/new`
  - existing job wizard plus `AI Generated` branch
- `/queue`
  - unchanged page with extra AI-generated review panels

## API routes

### AI niches
- `GET /api/ai-generated/niches`
  - list global niches with summary counts
- `POST /api/ai-generated/niches`
  - create niche
- `GET /api/ai-generated/niches/:nicheId`
  - get niche detail
- `PATCH /api/ai-generated/niches/:nicheId`
  - update niche metadata/status/provider defaults
- `POST /api/ai-generated/niches/:nicheId/archive`
  - archive niche
- `POST /api/ai-generated/niches/:nicheId/duplicate`
  - duplicate niche

### Prompt assets and versions
- `GET /api/ai-generated/niches/:nicheId/assets`
  - list asset heads + current versions
- `POST /api/ai-generated/niches/:nicheId/assets`
  - create asset slot if missing
- `POST /api/ai-generated/niches/:nicheId/assets/:assetType/versions`
  - upload replacement markdown file, create immutable version
- `GET /api/ai-generated/niches/:nicheId/assets/:assetType/versions`
  - list versions
- `GET /api/ai-generated/niches/:nicheId/assets/:assetType/versions/:versionId`
  - get version content and metadata
- `POST /api/ai-generated/niches/:nicheId/assets/:assetType/versions/:versionId/promote`
  - make a version active head
- `GET /api/ai-generated/niches/:nicheId/bundles/current`
  - get current active version bundle

### Taxonomy and weights
- `GET /api/ai-generated/niches/:nicheId/taxonomy`
  - list parsed/manual pillar/sub-angle activation state
- `PUT /api/ai-generated/niches/:nicheId/taxonomy`
  - bulk replace or patch taxonomy rows
- `POST /api/ai-generated/niches/:nicheId/taxonomy/reparse`
  - async parse prompt assets into taxonomy suggestions

### Jobs
- `POST /api/jobs`
  - existing route extended to accept `source_type = AI_GENERATED`
- `GET /api/jobs/:jobId`
  - existing route returns AI config if present
- `POST /api/jobs/:jobId/pause`
- `POST /api/jobs/:jobId/resume`
- `POST /api/jobs/:jobId/stop`

### Queue review actions
- `GET /api/queue`
  - existing filters extended with AI generation stage
- `POST /api/queue/posts/:postId/approve-text`
- `POST /api/queue/posts/:postId/regenerate-text`
- `POST /api/queue/posts/:postId/approve-images`
- `POST /api/queue/posts/:postId/regenerate-images`
- `POST /api/queue/bulk/approve-text`
- `POST /api/queue/bulk/approve-images`
- `PATCH /api/queue/posts/:postId/caption`
  - update caption body / CTA / hashtags only
- `PATCH /api/queue/posts/:postId/slides`
  - manual text edit to one or more slides; invalidates downstream images

### Internal orchestration
- `POST /api/internal/ai/jobs/:jobId/plan`
- `POST /api/internal/ai/posts/:postRunId/generate-text`
- `POST /api/internal/ai/posts/:postRunId/generate-visual-spine`
- `POST /api/internal/ai/posts/:postRunId/generate-image-prompts`
- `POST /api/internal/ai/posts/:postRunId/generate-images`
- `POST /api/internal/ai/posts/:postRunId/package`
- `POST /api/internal/ai/posts/:postRunId/retry-stage`

These internal routes should be worker-only, protected by service auth.

## Suggested frontend file map
- `app/(dashboard)/ai-generated/page.tsx`
- `app/(dashboard)/ai-generated/new/page.tsx`
- `app/(dashboard)/ai-generated/[nicheId]/page.tsx`
- `app/(dashboard)/ai-generated/[nicheId]/assets/page.tsx`
- `app/(dashboard)/ai-generated/[nicheId]/taxonomy/page.tsx`
- `app/(dashboard)/ai-generated/[nicheId]/versions/page.tsx`
- `app/(dashboard)/jobs/new/page.tsx`
- `app/(dashboard)/queue/page.tsx`

## Suggested server file map
- `app/api/ai-generated/niches/route.ts`
- `app/api/ai-generated/niches/[nicheId]/route.ts`
- `app/api/ai-generated/niches/[nicheId]/archive/route.ts`
- `app/api/ai-generated/niches/[nicheId]/duplicate/route.ts`
- `app/api/ai-generated/niches/[nicheId]/assets/route.ts`
- `app/api/ai-generated/niches/[nicheId]/assets/[assetType]/versions/route.ts`
- `app/api/ai-generated/niches/[nicheId]/assets/[assetType]/versions/[versionId]/route.ts`
- `app/api/ai-generated/niches/[nicheId]/assets/[assetType]/versions/[versionId]/promote/route.ts`
- `app/api/ai-generated/niches/[nicheId]/taxonomy/route.ts`
- `app/api/ai-generated/niches/[nicheId]/taxonomy/reparse/route.ts`
- `app/api/queue/posts/[postId]/approve-text/route.ts`
- `app/api/queue/posts/[postId]/regenerate-text/route.ts`
- `app/api/queue/posts/[postId]/approve-images/route.ts`
- `app/api/queue/posts/[postId]/regenerate-images/route.ts`
- `app/api/queue/posts/[postId]/caption/route.ts`
- `app/api/queue/posts/[postId]/slides/route.ts`
- `app/api/queue/bulk/approve-text/route.ts`
- `app/api/queue/bulk/approve-images/route.ts`
