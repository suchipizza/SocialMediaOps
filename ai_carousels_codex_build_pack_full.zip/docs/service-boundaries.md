# Service Boundaries

## Frontend
Responsible for:
- niche CRUD UI
- markdown asset upload UI
- taxonomy activation/weights UI
- job create UI
- queue review UI for text and image approvals
- publish preview of caption + CTA + hashtags

## API layer
Responsible for:
- auth
- validation
- job creation and snapshot freezing
- route orchestration
- returning normalized DTOs

## AI orchestration layer
Responsible for:
- batch planning
- stage enqueueing
- state transitions
- idempotency
- retries
- raw + normalized artifact persistence

## Provider adapters
Responsible for:
- provider-specific request formatting
- model selection
- normalized response envelopes
- usage metrics mapping
- error mapping to a common error type system

## Publishing layer
Existing responsibility remains:
- schedule eligible posts
- publish to Instagram/TikTok
- preserve current cadence logic

## Storage
Stores:
- markdown prompt asset versions
- generated slide images
- preview bundle assets
- redacted logs if stored as files
