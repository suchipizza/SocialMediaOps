# Worker Contracts

This document defines the stage workers, queue message envelopes, idempotency rules, and success/error contracts.

## Shared execution rules
- Each stage is idempotent.
- Retry only the failed stage by default.
- Persist both normalized artifacts and redacted raw provider envelopes.
- In-flight jobs always use the frozen `ai_niche_snapshot_id`.

## Shared queue envelope

```ts
type StageJobEnvelope = {
  traceId: string;
  jobId: string;
  postId: string;
  aiPostRunId: string;
  aiNicheSnapshotId: string;
  stage:
    | "PLAN_BATCH"
    | "GENERATE_TEXT"
    | "GENERATE_VISUAL_SPINE"
    | "GENERATE_IMAGE_PROMPTS"
    | "GENERATE_SLIDE_IMAGES"
    | "PACKAGE_FINAL_ASSETS";
  requestedBy: "system" | "user";
  requestedByUserId?: string;
  retryIndex: number;
  idempotencyKey: string;
  enqueueTs: string;
};
```

## Stage workers

### 1) `ai-batch-planner-worker`
Creates all `ai_post_runs` for a job and assigns pillar/sub-angle pairs.

Input:
- `jobId`
- `ai_job_config`
- frozen taxonomy from niche snapshot

Output:
- one `ai_post_runs` row per target post
- `planned_pillar_key`
- `planned_subangle_key`
- first stage jobs for `GENERATE_TEXT`

Failure policy:
- fail job creation if there are zero active pillars or zero active sub-angles
- no partial silent success

### 2) `ai-text-generation-worker`
Generates a structured text pack per post.

Inputs:
- niche snapshot asset versions
- selected pillar/sub-angle
- language
- slide_count = 10

Output artifact:
- `TEXT_PACK`
- `CAPTION`
- `CTA`
- `HASHTAGS`
- `METADATA_TAGS` (best effort)

Success transition:
- `generation_stage = WAIT_FOR_TEXT_APPROVAL`
- `generation_status = WAITING_FOR_REVIEW`
- `posts.status = READY_FOR_REVIEW`

Failure policy:
- retry provider/network failures
- validation failures stay on `GENERATE_TEXT` with `FAILED`

### 3) `ai-visual-spine-worker`
Runs only after text approval.

Inputs:
- approved text pack
- visual spine prompt asset
- niche description + workflow reference

Output artifact:
- `VISUAL_SPINE`

Success transition:
- enqueue `GENERATE_IMAGE_PROMPTS`

### 4) `ai-image-prompt-worker`
Creates a global style anchor plus one production prompt per slide.

Inputs:
- approved text pack
- visual spine artifact
- image prompt prompt asset

Output artifact:
- `IMAGE_PROMPTS`

Success transition:
- enqueue `GENERATE_SLIDE_IMAGES`

### 5) `ai-image-generation-worker`
Generates one final image per slide.

Inputs:
- image provider/model config
- `IMAGE_PROMPTS`
- output target `1080x1350` JPEG-compatible

Output:
- `ai_generated_assets` rows for each slide
- provider asset/job IDs if present

Success transition:
- `generation_stage = WAIT_FOR_IMAGE_APPROVAL`
- `generation_status = WAITING_FOR_REVIEW`

### 6) `ai-packaging-worker`
Validates, orders, and finalizes the slide images for scheduling/publishing.

Inputs:
- approved generated slide images
- caption/cta/hashtags state from `posts`

Output:
- ordered final assets
- preview bundle
- publish-ready marker

Success transition:
- `generation_stage = READY_FOR_SCHEDULING`
- `generation_status = APPROVED`
- downstream post state set to `APPROVED` or `RENDERED` according to existing scheduler contract

## Review action contracts

### Text approval
Action:
- validate current text pack exists
- persist approval event
- enqueue `GENERATE_VISUAL_SPINE`

### Text regenerate
Action:
- increment text artifact version number
- soft-delete or supersede prior text artifacts
- reset downstream artifacts if they exist
- enqueue `GENERATE_TEXT`

### Image approval
Action:
- validate 10 slide images exist
- enqueue `PACKAGE_FINAL_ASSETS`

### Image regenerate
Action:
- supersede prior generated image rows
- keep text/visual spine/image prompt artifacts
- enqueue `GENERATE_SLIDE_IMAGES`

## Idempotency key formula
Recommended:
`sha256(postId + stage + artifactInputHash + provider + model + retryIndex)`

## Result contract

```ts
type StageResultEnvelope = {
  traceId: string;
  aiPostRunId: string;
  stage: string;
  status: "SUCCEEDED" | "FAILED" | "RETRYING";
  retryIndex: number;
  idempotencyKey: string;
  provider?: string;
  model?: string;
  latencyMs?: number;
  usage?: Record<string, unknown>;
  outputRefs?: Array<{
    kind: "artifact" | "asset";
    id: string;
    artifactType?: string;
    slideIndex?: number;
  }>;
  error?: {
    code: string;
    message: string;
    retriable: boolean;
    detail?: Record<string, unknown>;
  };
  completedAt: string;
};
```

## Suggested queue topics
- `ai.plan-batch`
- `ai.generate-text`
- `ai.generate-visual-spine`
- `ai.generate-image-prompts`
- `ai.generate-slide-images`
- `ai.package-final-assets`

## Observability minimum
Every stage attempt must write:
- start event
- finish event
- latency
- provider/model
- redacted request payload
- redacted response payload
- retry metadata
