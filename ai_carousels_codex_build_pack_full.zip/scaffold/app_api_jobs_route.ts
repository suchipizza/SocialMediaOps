import { NextRequest, NextResponse } from "next/server";

export async function POST(req: NextRequest) {
  const body = await req.json();

  // TODO:
  // 1. validate sourceType
  // 2. if AI_GENERATED, freeze active niche asset heads into ai_niche_snapshot
  // 3. create job row + ai_job_config row
  // 4. enqueue PLAN_BATCH worker
  // 5. return identifiers

  return NextResponse.json(
    {
      ok: true,
      message: "Stub route. Implement snapshot freeze + job creation.",
      received: body
    },
    { status: 201 }
  );
}
