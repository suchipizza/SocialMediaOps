import type { StageJobEnvelope, StageResultEnvelope } from "../../types/worker-contracts";

export async function handleGenerateText(job: StageJobEnvelope): Promise<StageResultEnvelope> {
  // TODO:
  // 1. load ai_post_run + snapshot
  // 2. compose prompt inputs
  // 3. call provider adapter
  // 4. normalize text pack
  // 5. persist artifacts
  // 6. set WAIT_FOR_TEXT_APPROVAL
  return {
    traceId: job.traceId,
    aiPostRunId: job.aiPostRunId,
    stage: "GENERATE_TEXT",
    status: "SUCCEEDED",
    retryIndex: job.retryIndex,
    idempotencyKey: job.idempotencyKey,
    completedAt: new Date().toISOString()
  };
}
