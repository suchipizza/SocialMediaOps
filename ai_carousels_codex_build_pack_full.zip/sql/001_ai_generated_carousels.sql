-- 001_ai_generated_carousels.sql
-- Additive PostgreSQL migration for the AI-generated carousel pipeline.
-- Assumptions:
--   - existing tables `jobs` and `posts` already exist
--   - IDs are text/uuid compatible; this migration uses UUID defaults for new tables
--   - adjust enum/value integration if your existing schema uses different column types

create extension if not exists pgcrypto;

do $$
begin
  if not exists (select 1 from pg_type where typname = 'ai_niche_status') then
    create type ai_niche_status as enum ('DRAFT', 'ACTIVE', 'ARCHIVED');
  end if;
  if not exists (select 1 from pg_type where typname = 'prompt_asset_type') then
    create type prompt_asset_type as enum (
      'NICHE_DESCRIPTION_MD',
      'TEXT_GENERATION_PROMPT_MD',
      'VISUAL_SPINE_PROMPT_MD',
      'IMAGE_PROMPT_PROMPT_MD',
      'CONTENT_PILLARS_MD',
      'CONTENT_OS_MD',
      'WORKFLOW_REFERENCE_MD',
      'PROMPT_FORMAT_SPEC_MD',
      'OPTIMIZER_GUIDELINES_MD',
      'BRAND_STYLE_NOTES_MD',
      'EXAMPLES_MD'
    );
  end if;
  if not exists (select 1 from pg_type where typname = 'prompt_asset_version_status') then
    create type prompt_asset_version_status as enum ('ACTIVE', 'DRAFT', 'ARCHIVED', 'PROPOSED_BY_OPTIMIZER');
  end if;
  if not exists (select 1 from pg_type where typname = 'mix_mode') then
    create type mix_mode as enum ('AUTO_BALANCED', 'WEIGHTED', 'MANUAL_TARGETS');
  end if;
  if not exists (select 1 from pg_type where typname = 'ai_generation_stage') then
    create type ai_generation_stage as enum (
      'PLAN_BATCH',
      'GENERATE_TEXT',
      'WAIT_FOR_TEXT_APPROVAL',
      'GENERATE_VISUAL_SPINE',
      'GENERATE_IMAGE_PROMPTS',
      'GENERATE_SLIDE_IMAGES',
      'WAIT_FOR_IMAGE_APPROVAL',
      'PACKAGE_FINAL_ASSETS',
      'READY_FOR_SCHEDULING',
      'DONE',
      'FAILED'
    );
  end if;
  if not exists (select 1 from pg_type where typname = 'ai_generation_status') then
    create type ai_generation_status as enum ('PENDING', 'RUNNING', 'WAITING_FOR_REVIEW', 'APPROVED', 'REJECTED', 'RETRYING', 'FAILED');
  end if;
  if not exists (select 1 from pg_type where typname = 'ai_artifact_type') then
    create type ai_artifact_type as enum (
      'TEXT_PACK',
      'VISUAL_SPINE',
      'IMAGE_PROMPTS',
      'CAPTION',
      'CTA',
      'HASHTAGS',
      'METADATA_TAGS'
    );
  end if;
  if not exists (select 1 from pg_type where typname = 'ai_generated_asset_role') then
    create type ai_generated_asset_role as enum ('SLIDE_IMAGE', 'FINAL_SLIDE_ASSET', 'PREVIEW_THUMBNAIL');
  end if;
  if not exists (select 1 from pg_type where typname = 'ai_event_status') then
    create type ai_event_status as enum ('STARTED', 'SUCCEEDED', 'FAILED', 'RETRYING');
  end if;
end$$;

create table if not exists ai_niches (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text not null unique,
  description text,
  status ai_niche_status not null default 'DRAFT',
  default_text_provider text not null,
  default_text_model text not null,
  default_reasoning_provider text not null,
  default_reasoning_model text not null,
  default_image_provider text not null,
  default_image_model text not null,
  default_language text not null default 'en',
  default_slide_count integer not null default 10 check (default_slide_count = 10),
  default_mix_mode mix_mode not null default 'AUTO_BALANCED',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists ai_prompt_assets (
  id uuid primary key default gen_random_uuid(),
  ai_niche_id uuid not null references ai_niches(id) on delete cascade,
  asset_type prompt_asset_type not null,
  display_name text not null,
  active_version_id uuid null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (ai_niche_id, asset_type)
);

create table if not exists ai_prompt_asset_versions (
  id uuid primary key default gen_random_uuid(),
  prompt_asset_id uuid not null references ai_prompt_assets(id) on delete cascade,
  version_number integer not null,
  filename text not null,
  storage_path text not null,
  checksum text not null,
  content_text text not null,
  status prompt_asset_version_status not null default 'ACTIVE',
  uploaded_by text,
  notes text,
  created_at timestamptz not null default now(),
  unique (prompt_asset_id, version_number)
);

alter table ai_prompt_assets
  drop constraint if exists fk_ai_prompt_assets_active_version;

alter table ai_prompt_assets
  add constraint fk_ai_prompt_assets_active_version
  foreign key (active_version_id) references ai_prompt_asset_versions(id);

create table if not exists ai_niche_taxonomy (
  id uuid primary key default gen_random_uuid(),
  ai_niche_id uuid not null references ai_niches(id) on delete cascade,
  pillar_key text not null,
  pillar_name text not null,
  pillar_is_active boolean not null default true,
  pillar_weight numeric(8,2) not null default 1.0,
  subangle_key text not null,
  subangle_name text not null,
  subangle_is_active boolean not null default true,
  subangle_weight numeric(8,2) not null default 1.0,
  visual_world_key text,
  visual_world_name text,
  source text not null default 'manual_or_parsed',
  updated_at timestamptz not null default now()
);

create table if not exists ai_niche_snapshots (
  id uuid primary key default gen_random_uuid(),
  ai_niche_id uuid not null references ai_niches(id) on delete restrict,
  bundle_version integer not null,
  text_provider text not null,
  text_model text not null,
  reasoning_provider text not null,
  reasoning_model text not null,
  image_provider text not null,
  image_model text not null,
  language text not null,
  slide_count integer not null check (slide_count = 10),
  mix_mode mix_mode not null,
  snapshot_json jsonb not null,
  created_at timestamptz not null default now(),
  unique (ai_niche_id, bundle_version)
);

create table if not exists ai_job_configs (
  id uuid primary key default gen_random_uuid(),
  job_id uuid not null unique,
  ai_niche_snapshot_id uuid not null references ai_niche_snapshots(id) on delete restrict,
  target_post_count integer not null check (target_post_count > 0),
  mix_mode mix_mode not null,
  mix_config_json jsonb,
  language text not null default 'en',
  slide_count integer not null default 10 check (slide_count = 10),
  status text not null default 'RUNNING',
  created_at timestamptz not null default now()
);

create table if not exists ai_post_runs (
  id uuid primary key default gen_random_uuid(),
  post_id uuid not null unique,
  job_id uuid not null,
  ai_niche_snapshot_id uuid not null references ai_niche_snapshots(id) on delete restrict,
  planned_pillar_key text not null,
  planned_subangle_key text not null,
  selected_visual_world_key text,
  generation_stage ai_generation_stage not null default 'PLAN_BATCH',
  generation_status ai_generation_status not null default 'PENDING',
  retry_count integer not null default 0,
  last_error_code text,
  last_error_message text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists ai_post_artifacts (
  id uuid primary key default gen_random_uuid(),
  ai_post_run_id uuid not null references ai_post_runs(id) on delete cascade,
  artifact_type ai_artifact_type not null,
  version_number integer not null default 1,
  content_json jsonb,
  raw_text text,
  created_at timestamptz not null default now(),
  unique (ai_post_run_id, artifact_type, version_number)
);

create table if not exists ai_generated_assets (
  id uuid primary key default gen_random_uuid(),
  ai_post_run_id uuid not null references ai_post_runs(id) on delete cascade,
  asset_role ai_generated_asset_role not null,
  slide_index integer not null check (slide_index between 1 and 10),
  storage_url text not null,
  mime_type text not null,
  width integer,
  height integer,
  file_size_bytes bigint,
  provider_asset_id text,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists ai_generation_events (
  id uuid primary key default gen_random_uuid(),
  ai_post_run_id uuid not null references ai_post_runs(id) on delete cascade,
  stage ai_generation_stage not null,
  event_type text not null,
  provider text,
  model text,
  request_payload_redacted jsonb,
  response_payload_redacted jsonb,
  latency_ms integer,
  usage_json jsonb,
  status ai_event_status not null,
  error_json jsonb,
  created_at timestamptz not null default now()
);

create table if not exists ai_post_metadata_labels (
  id uuid primary key default gen_random_uuid(),
  ai_post_run_id uuid not null unique references ai_post_runs(id) on delete cascade,
  pillar text,
  sub_angle text,
  hook_family text,
  emotional_effect text,
  visual_world text,
  first_slide_strength text,
  save_line text,
  caption_cta_type text,
  performance_score numeric(8,2),
  labels_json jsonb,
  updated_at timestamptz not null default now()
);

-- Additive extensions to existing tables.
alter table if exists jobs
  add column if not exists source_type text;

alter table if exists jobs
  add column if not exists ai_job_config_id uuid null references ai_job_configs(id) on delete set null;

alter table if exists posts
  add column if not exists content_source_type text,
  add column if not exists caption_body text,
  add column if not exists caption_cta text,
  add column if not exists hashtags_json jsonb,
  add column if not exists language text,
  add column if not exists slide_count integer,
  add column if not exists ai_post_run_id uuid null references ai_post_runs(id) on delete set null;

create index if not exists idx_ai_prompt_assets_niche on ai_prompt_assets(ai_niche_id);
create index if not exists idx_ai_prompt_asset_versions_asset on ai_prompt_asset_versions(prompt_asset_id, version_number desc);
create index if not exists idx_ai_niche_taxonomy_niche on ai_niche_taxonomy(ai_niche_id, pillar_is_active, subangle_is_active);
create index if not exists idx_ai_job_configs_snapshot on ai_job_configs(ai_niche_snapshot_id);
create index if not exists idx_ai_post_runs_job on ai_post_runs(job_id, generation_stage, generation_status);
create index if not exists idx_ai_post_artifacts_run on ai_post_artifacts(ai_post_run_id, artifact_type, version_number desc);
create index if not exists idx_ai_generated_assets_run on ai_generated_assets(ai_post_run_id, asset_role, slide_index);
create index if not exists idx_ai_generation_events_run on ai_generation_events(ai_post_run_id, stage, created_at desc);
create index if not exists idx_ai_post_metadata_labels_run on ai_post_metadata_labels(ai_post_run_id);

-- Trigger helper for updated_at.
create or replace function set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists trg_ai_niches_updated_at on ai_niches;
create trigger trg_ai_niches_updated_at
before update on ai_niches
for each row execute function set_updated_at();

drop trigger if exists trg_ai_prompt_assets_updated_at on ai_prompt_assets;
create trigger trg_ai_prompt_assets_updated_at
before update on ai_prompt_assets
for each row execute function set_updated_at();

drop trigger if exists trg_ai_post_runs_updated_at on ai_post_runs;
create trigger trg_ai_post_runs_updated_at
before update on ai_post_runs
for each row execute function set_updated_at();

-- Optional check constraints for new additive columns.
do $$
begin
  if exists (
    select 1
    from information_schema.columns
    where table_name = 'jobs'
      and column_name = 'source_type'
  ) then
    begin
      alter table jobs
        add constraint jobs_source_type_check
        check (source_type is null or source_type in ('CSV', 'GOOGLE_SHEETS', 'MANUAL', 'AI_GENERATED', 'TEMPLATE'));
    exception when duplicate_object then
      null;
    end;
  end if;

  if exists (
    select 1
    from information_schema.columns
    where table_name = 'posts'
      and column_name = 'content_source_type'
  ) then
    begin
      alter table posts
        add constraint posts_content_source_type_check
        check (content_source_type is null or content_source_type in ('TEMPLATE', 'AI_GENERATED', 'MANUAL', 'IMPORTED'));
    exception when duplicate_object then
      null;
    end;
  end if;
end$$;

create unique index if not exists uq_ai_niche_taxonomy_keys on ai_niche_taxonomy (ai_niche_id, pillar_key, subangle_key, coalesce(visual_world_key, ''));
