-- 002_seed_enums_and_views.sql
-- Optional helper view layer and starter seed rows.

create or replace view v_ai_niche_asset_heads as
select
  n.id as ai_niche_id,
  n.name as ai_niche_name,
  a.id as prompt_asset_id,
  a.asset_type,
  a.display_name,
  a.active_version_id,
  v.version_number as active_version_number,
  v.filename as active_filename,
  v.checksum as active_checksum,
  v.created_at as active_version_created_at
from ai_niches n
join ai_prompt_assets a on a.ai_niche_id = n.id
left join ai_prompt_asset_versions v on v.id = a.active_version_id;

create or replace view v_ai_post_current_artifacts as
select distinct on (ai_post_run_id, artifact_type)
  id,
  ai_post_run_id,
  artifact_type,
  version_number,
  content_json,
  raw_text,
  created_at
from ai_post_artifacts
order by ai_post_run_id, artifact_type, version_number desc;

create or replace view v_ai_post_current_slide_assets as
select distinct on (ai_post_run_id, asset_role, slide_index)
  id,
  ai_post_run_id,
  asset_role,
  slide_index,
  storage_url,
  mime_type,
  width,
  height,
  file_size_bytes,
  provider_asset_id,
  is_active,
  created_at
from ai_generated_assets
where is_active = true
order by ai_post_run_id, asset_role, slide_index, created_at desc;

create index if not exists idx_v_ai_post_current_artifacts_lookup
on ai_post_artifacts (ai_post_run_id, artifact_type, version_number desc);

create index if not exists idx_v_ai_post_current_slide_assets_lookup
on ai_generated_assets (ai_post_run_id, asset_role, slide_index, is_active, created_at desc);
