export interface CreateAiGeneratedJobRequest {
  projectId: string;
  sourceType: "AI_GENERATED";
  startDate: string;
  targetPostCount: number;
  title?: string;
  aiConfig: {
    nicheId: string;
    mixMode: "AUTO_BALANCED" | "WEIGHTED" | "MANUAL_TARGETS";
    mixConfig?: Record<string, unknown> | null;
    language: "en";
    slideCount: 10;
    overrideTextProvider?: string | null;
    overrideTextModel?: string | null;
    overrideReasoningProvider?: string | null;
    overrideReasoningModel?: string | null;
  };
}

export interface UpdateCaptionRequest {
  captionBody?: string;
  captionCta?: string;
  hashtags?: string[];
}
