export type AiNicheStatus = "DRAFT" | "ACTIVE" | "ARCHIVED";
export type PromptAssetType =
  | "NICHE_DESCRIPTION_MD"
  | "TEXT_GENERATION_PROMPT_MD"
  | "VISUAL_SPINE_PROMPT_MD"
  | "IMAGE_PROMPT_PROMPT_MD"
  | "CONTENT_PILLARS_MD"
  | "CONTENT_OS_MD"
  | "WORKFLOW_REFERENCE_MD"
  | "PROMPT_FORMAT_SPEC_MD"
  | "OPTIMIZER_GUIDELINES_MD"
  | "BRAND_STYLE_NOTES_MD"
  | "EXAMPLES_MD";

export type MixMode = "AUTO_BALANCED" | "WEIGHTED" | "MANUAL_TARGETS";

export type AiGenerationStage =
  | "PLAN_BATCH"
  | "GENERATE_TEXT"
  | "WAIT_FOR_TEXT_APPROVAL"
  | "GENERATE_VISUAL_SPINE"
  | "GENERATE_IMAGE_PROMPTS"
  | "GENERATE_SLIDE_IMAGES"
  | "WAIT_FOR_IMAGE_APPROVAL"
  | "PACKAGE_FINAL_ASSETS"
  | "READY_FOR_SCHEDULING"
  | "DONE"
  | "FAILED";

export type AiGenerationStatus =
  | "PENDING"
  | "RUNNING"
  | "WAITING_FOR_REVIEW"
  | "APPROVED"
  | "REJECTED"
  | "RETRYING"
  | "FAILED";

export interface AiNiche {
  id: string;
  name: string;
  slug: string;
  description?: string;
  status: AiNicheStatus;
  defaultTextProvider: string;
  defaultTextModel: string;
  defaultReasoningProvider: string;
  defaultReasoningModel: string;
  defaultImageProvider: string;
  defaultImageModel: string;
  defaultLanguage: "en";
  defaultSlideCount: 10;
  defaultMixMode: MixMode;
  createdAt: string;
  updatedAt: string;
}

export interface TextPackSlide {
  slideIndex: number;
  headline: string;
  bodyCopy: string;
  visualDirection?: string;
}

export interface TextPackArtifact {
  selectedPillar: string;
  selectedSubangle: string;
  selectedVisualWorld?: string;
  emotionalEffect?: string;
  slides: TextPackSlide[];
  captionBody: string;
  captionCta: string;
  hashtags: string[];
}

export interface VisualSpineArtifact {
  hiddenMechanism: string;
  emotionalTheater: string;
  visualWorld: string[];
  recurringMotifs: string[];
  visualContrastSystem: string[];
  slideShotPlan: Array<{
    slideIndex: number;
    visualRole: string;
    shotType: string;
    mustShow: string;
    connectionToWorld: string;
    variationNote: string;
    aiImagePrompt?: string;
  }>;
  consistencyCheck?: Record<string, string | string[]>;
}

export interface ImagePromptsArtifact {
  globalStyleAnchor: string;
  prompts: Array<{
    slideIndex: number;
    productionPrompt: string;
  }>;
  artDirectionNotes?: {
    recurringMotifs?: string[];
    colorLightingContinuity?: string;
    cohesionDriver?: string;
    antiRepetitionDriver?: string;
    bestTextPlacementStrategy?: string;
  };
}
