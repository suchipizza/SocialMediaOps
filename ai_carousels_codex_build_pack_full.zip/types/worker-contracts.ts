import { AiGenerationStage } from "./domain";

export interface StageJobEnvelope {
  traceId: string;
  jobId: string;
  postId: string;
  aiPostRunId: string;
  aiNicheSnapshotId: string;
  stage:
    | "PLAN_BATCH"
    | "GENERATE_TEXT"
    | "GENERATE_VISUAL_SPINE"
    | "GENERATE_IMAGE_PROMPTS"
    | "GENERATE_SLIDE_IMAGES"
    | "PACKAGE_FINAL_ASSETS";
  requestedBy: "system" | "user";
  requestedByUserId?: string;
  retryIndex: number;
  idempotencyKey: string;
  enqueueTs: string;
}

export interface StageResultEnvelope {
  traceId: string;
  aiPostRunId: string;
  stage: AiGenerationStage;
  status: "SUCCEEDED" | "FAILED" | "RETRYING";
  retryIndex: number;
  idempotencyKey: string;
  provider?: string;
  model?: string;
  latencyMs?: number;
  usage?: Record<string, unknown>;
  outputRefs?: Array<{
    kind: "artifact" | "asset";
    id: string;
    artifactType?: string;
    slideIndex?: number;
  }>;
  error?: {
    code: string;
    message: string;
    retriable: boolean;
    detail?: Record<string, unknown>;
  };
  completedAt: string;
}
