import { NextResponse } from "next/server";

/**
 * TODO:
 * - POST: create job (ingest method: CSV/Sheets/manual/AI)
 * - GET: list jobs
 */
export async function GET() {
  return NextResponse.json({ jobs: [] });
}

export async function POST() {
  return NextResponse.json({ error: "not_implemented" }, { status: 501 });
}
