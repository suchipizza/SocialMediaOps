import { NextResponse } from "next/server";

/**
 * TODO:
 * - GET: list projects
 * - POST: create project
 * Use packages/db for queries.
 */
export async function GET() {
  return NextResponse.json({ projects: [] });
}

export async function POST() {
  return NextResponse.json({ error: "not_implemented" }, { status: 501 });
}
