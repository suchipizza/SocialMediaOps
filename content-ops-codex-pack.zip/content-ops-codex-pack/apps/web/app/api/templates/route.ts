import { NextResponse } from "next/server";

/**
 * TODO:
 * - POST: upload template pack (.zip), store, validate manifest
 * - GET: list templates
 */
export async function GET() {
  return NextResponse.json({ templates: [] });
}

export async function POST() {
  return NextResponse.json({ error: "not_implemented" }, { status: 501 });
}
