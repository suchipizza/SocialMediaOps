export default function JobsPage() {
  return (
    <div>
      <h1>Jobs</h1>
      <p>TODO: job wizard (CSV import / manual / AI), start date, controls, logs.</p>
    </div>
  );
}
