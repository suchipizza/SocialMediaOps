export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body style={{ fontFamily: "system-ui, sans-serif", margin: 0 }}>
        <div style={{ display: "flex", minHeight: "100vh" }}>
          <aside style={{ width: 280, borderRight: "1px solid #eee", padding: 16 }}>
            <h2>Content Ops</h2>
            <nav style={{ display: "grid", gap: 8 }}>
              <a href="/projects">Projects</a>
              <a href="/templates">Templates</a>
              <a href="/queue">Queue</a>
              <a href="/jobs">Jobs</a>
              <a href="/settings">Settings</a>
            </nav>
          </aside>
          <main style={{ flex: 1, padding: 24 }}>{children}</main>
        </div>
      </body>
    </html>
  );
}
