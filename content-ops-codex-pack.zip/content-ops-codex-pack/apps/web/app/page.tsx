export default function Home() {
  return (
    <div>
      <h1>Dashboard</h1>
      <p>Choose a section from the sidebar.</p>
    </div>
  );
}
