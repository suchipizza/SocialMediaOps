export default function ProjectsPage() {
  return (
    <div>
      <h1>Projects</h1>
      <p>TODO: list projects, create/edit/delete.</p>
    </div>
  );
}
