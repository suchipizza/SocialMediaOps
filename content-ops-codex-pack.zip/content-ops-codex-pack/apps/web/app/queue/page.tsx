export default function QueuePage() {
  return (
    <div>
      <h1>Queue</h1>
      <p>TODO: filter by status/pillar/job, bulk approve/reject, edit, preview, re-render.</p>
    </div>
  );
}
