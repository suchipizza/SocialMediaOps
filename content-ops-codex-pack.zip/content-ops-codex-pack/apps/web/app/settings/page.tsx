export default function SettingsPage() {
  return (
    <div>
      <h1>Settings</h1>
      <p>TODO: account settings, token reconnect, environment checks.</p>
    </div>
  );
}
