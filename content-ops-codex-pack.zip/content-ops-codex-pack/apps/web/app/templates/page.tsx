export default function TemplatesPage() {
  return (
    <div>
      <h1>Templates</h1>
      <p>TODO: upload template packs (.zip), validate manifest, preview, delete.</p>
    </div>
  );
}
