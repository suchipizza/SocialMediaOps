import { ManifestSchema } from "./schema.js";

/**
 * Validate a manifest object. Throws on invalid.
 */
export function validateManifest(input: unknown) {
  return ManifestSchema.parse(input);
}
